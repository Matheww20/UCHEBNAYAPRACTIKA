import '../models/author.dart';
import '../models/book.dart';
import '../models/genre.dart';
import '../models/publisher.dart';

const genres = [
  Genre(1, 'Художественная'),
  Genre(2, 'Фантастика'),
  Genre(3, 'История'),
  Genre(4, 'Финансы'),
  Genre(5, 'Программирование'),
];

const publishers = [
  Publisher(1, 'АСТ'),
  Publisher(2, 'Эксмо'),
  Publisher(3, 'Питер'),
  Publisher(4, 'Капитал Пресс'),
  Publisher(5, 'МИФ'),
];

const seedAuthors = [
  Author(id: 1, lastName: 'Толстой', firstName: 'Лев', country: 'Россия', birthYear: 1828),
  Author(id: 2, lastName: 'Достоевский', firstName: 'Фёдор', country: 'Россия', birthYear: 1821),
  Author(id: 3, lastName: 'Булгаков', firstName: 'Михаил', country: 'Россия', birthYear: 1891),
  Author(id: 4, lastName: 'Оруэлл', firstName: 'Джордж', country: 'Великобритания', birthYear: 1903),
  Author(id: 5, lastName: 'Брэдбери', firstName: 'Рэй', country: 'США', birthYear: 1920),
  Author(id: 6, lastName: 'Кинг', firstName: 'Стивен', country: 'США', birthYear: 1947),
  Author(id: 7, lastName: 'Мартин', firstName: 'Роберт', country: 'США', birthYear: 1952),
  Author(id: 8, lastName: 'Кнут', firstName: 'Дональд', country: 'США', birthYear: 1938),
  Author(id: 9, lastName: 'Глуховский', firstName: 'Дмитрий', country: 'Россия', birthYear: 1979),
  Author(id: 10, lastName: 'Пелевин', firstName: 'Виктор', country: 'Россия', birthYear: 1962),
];

const seedBooks = [
  Book(id: 1, title: 'Война и мир', isbn: '978-5-17-118365-1', year: 1869, pages: 1274, publisherId: 1, authorIds: [1], genreIds: [1, 3], copiesTotal: 8, copiesAvailable: 3),
  Book(id: 2, title: 'Анна Каренина', isbn: '978-5-17-090331-3', year: 1877, pages: 864, publisherId: 1, authorIds: [1], genreIds: [1], copiesTotal: 7, copiesAvailable: 2),
  Book(id: 3, title: 'Преступление и наказание', isbn: '978-5-17-090630-7', year: 1866, pages: 672, publisherId: 1, authorIds: [2], genreIds: [1], copiesTotal: 9, copiesAvailable: 4),
  Book(id: 4, title: 'Братья Карамазовы', isbn: '978-5-04-117611-0', year: 1880, pages: 992, publisherId: 2, authorIds: [2], genreIds: [1], copiesTotal: 6, copiesAvailable: 2),
  Book(id: 5, title: 'Мастер и Маргарита', isbn: '978-5-17-090602-4', year: 1967, pages: 512, publisherId: 1, authorIds: [3], genreIds: [1, 2], copiesTotal: 12, copiesAvailable: 5),
  Book(id: 6, title: 'Собачье сердце', isbn: '978-5-04-112332-9', year: 1925, pages: 224, publisherId: 2, authorIds: [3], genreIds: [1, 2], copiesTotal: 7, copiesAvailable: 1),
  Book(id: 7, title: '1984', isbn: '978-5-17-080115-6', year: 1949, pages: 320, publisherId: 2, authorIds: [4], genreIds: [2], copiesTotal: 11, copiesAvailable: 6),
  Book(id: 8, title: 'Скотный двор', isbn: '978-5-17-109867-2', year: 1945, pages: 160, publisherId: 2, authorIds: [4], genreIds: [1], copiesTotal: 5, copiesAvailable: 3),
  Book(id: 9, title: '451 градус по Фаренгейту', isbn: '978-5-17-083001-9', year: 1953, pages: 256, publisherId: 2, authorIds: [5], genreIds: [2], copiesTotal: 10, copiesAvailable: 4),
  Book(id: 10, title: 'Вино из одуванчиков', isbn: '978-5-17-104332-2', year: 1957, pages: 320, publisherId: 1, authorIds: [5], genreIds: [1], copiesTotal: 4, copiesAvailable: 1),
  Book(id: 11, title: 'Оно', isbn: '978-5-17-120409-7', year: 1986, pages: 1248, publisherId: 1, authorIds: [6], genreIds: [2], copiesTotal: 8, copiesAvailable: 2),
  Book(id: 12, title: 'Зелёная миля', isbn: '978-5-17-122887-1', year: 1996, pages: 384, publisherId: 1, authorIds: [6], genreIds: [1], copiesTotal: 6, copiesAvailable: 2),
  Book(id: 13, title: 'Чистый код', isbn: '978-5-4461-0960-9', year: 2008, pages: 464, publisherId: 3, authorIds: [7], genreIds: [5], copiesTotal: 14, copiesAvailable: 8),
  Book(id: 14, title: 'Чистая архитектура', isbn: '978-5-4461-0772-8', year: 2017, pages: 352, publisherId: 3, authorIds: [7], genreIds: [5], copiesTotal: 10, copiesAvailable: 5),
  Book(id: 15, title: 'Искусство программирования. Том 1', isbn: '978-5-8459-0080-0', year: 1968, pages: 720, publisherId: 3, authorIds: [8], genreIds: [5], copiesTotal: 5, copiesAvailable: 2),
  Book(id: 16, title: 'Искусство программирования. Том 2', isbn: '978-5-8459-0081-7', year: 1969, pages: 832, publisherId: 3, authorIds: [8], genreIds: [5], copiesTotal: 4, copiesAvailable: 1),
  Book(id: 17, title: 'Метро 2033', isbn: '978-5-17-121538-3', year: 2005, pages: 544, publisherId: 1, authorIds: [9], genreIds: [2], copiesTotal: 9, copiesAvailable: 3),
  Book(id: 18, title: 'Метро 2034', isbn: '978-5-17-121539-0', year: 2009, pages: 448, publisherId: 1, authorIds: [9], genreIds: [2], copiesTotal: 7, copiesAvailable: 4),
  Book(id: 19, title: 'Generation «П»', isbn: '978-5-17-080234-4', year: 1999, pages: 336, publisherId: 2, authorIds: [10], genreIds: [1], copiesTotal: 6, copiesAvailable: 3),
  Book(id: 20, title: 'Чапаев и Пустота', isbn: '978-5-17-099532-5', year: 1996, pages: 416, publisherId: 2, authorIds: [10], genreIds: [1], copiesTotal: 5, copiesAvailable: 2),
  Book(id: 21, title: 'Деньги как инструмент', isbn: '978-5-94614-123-7', year: 2018, pages: 288, publisherId: 4, authorIds: [7], genreIds: [4], copiesTotal: 8, copiesAvailable: 4),
  Book(id: 22, title: 'История денег', isbn: '978-5-17-134001-2', year: 2014, pages: 400, publisherId: 5, authorIds: [4], genreIds: [3, 4], copiesTotal: 6, copiesAvailable: 3),
  Book(id: 23, title: 'Финансы без паники', isbn: '978-5-00169-777-8', year: 2021, pages: 304, publisherId: 5, authorIds: [7], genreIds: [4], copiesTotal: 9, copiesAvailable: 6),
  Book(id: 24, title: 'Алгоритмы для начинающих', isbn: '978-5-4461-2044-4', year: 2020, pages: 368, publisherId: 3, authorIds: [8], genreIds: [5], copiesTotal: 10, copiesAvailable: 7),
];

String publisherName(int id) {
  for (final item in publishers) {
    if (item.id == id) return item.name;
  }
  return 'Неизвестно';
}

String authorName(int id) {
  for (final item in seedAuthors) {
    if (item.id == id) return item.fullName;
  }
  return 'Неизвестно';
}

String genreName(int id) {
  for (final item in genres) {
    if (item.id == id) return item.name;
  }
  return 'Неизвестно';
}

int booksCountForAuthor(int authorId) {
  return seedBooks.where((b) => b.authorIds.contains(authorId)).length;
}
