import 'package:flutter/foundation.dart';

class Session extends ChangeNotifier {
  String? accessToken;
  String? refreshToken;
  String? username;
  String? role;

  bool get isLoggedIn => accessToken != null;

  void setTokens({
    required String access,
    required String refresh,
    required String usernameValue,
    required String roleValue,
  }) {
    accessToken = access;
    refreshToken = refresh;
    username = usernameValue;
    role = roleValue;
    notifyListeners();
  }

  void clear() {
    accessToken = null;
    refreshToken = null;
    username = null;
    role = null;
    notifyListeners();
  }
}
