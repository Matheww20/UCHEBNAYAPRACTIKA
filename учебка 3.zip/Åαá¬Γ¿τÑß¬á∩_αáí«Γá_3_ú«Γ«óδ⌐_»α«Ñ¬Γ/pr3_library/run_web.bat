@echo off
flutter pub get
flutter run -d chrome --web-port=5557
pause
