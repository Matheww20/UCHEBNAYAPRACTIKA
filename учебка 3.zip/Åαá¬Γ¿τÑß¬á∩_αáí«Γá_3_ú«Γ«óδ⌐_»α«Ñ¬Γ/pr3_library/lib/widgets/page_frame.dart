import 'package:flutter/material.dart';

class PageFrame extends StatelessWidget {
  const PageFrame({
    super.key,
    required this.child,
    this.maxWidth = 1400,
  });

  final Widget child;
  final double maxWidth;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth < maxWidth
            ? constraints.maxWidth
            : maxWidth;

        return Center(
          child: SizedBox(
            width: width,
            height: constraints.maxHeight,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: child,
            ),
          ),
        );
      },
    );
  }
}
