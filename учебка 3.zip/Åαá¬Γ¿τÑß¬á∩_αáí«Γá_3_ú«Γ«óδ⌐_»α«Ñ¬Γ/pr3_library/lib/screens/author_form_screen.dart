import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/author.dart';
import '../state/author_list_notifier.dart';
import '../validation/validators.dart';
import '../widgets/entity_form_scaffold.dart';

class AuthorFormScreen extends StatefulWidget {
  const AuthorFormScreen({super.key, this.id});

  final int? id;
  bool get editing => id != null;

  @override
  State<AuthorFormScreen> createState() => _AuthorFormScreenState();
}

class _AuthorFormScreenState extends State<AuthorFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _lastName = TextEditingController();
  final _firstName = TextEditingController();
  final _country = TextEditingController();
  final _birthYear = TextEditingController();

  bool _loading = true;
  bool _dirty = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
    for (final c in [_lastName, _firstName, _country, _birthYear]) {
      c.addListener(() {
        if (mounted) setState(() => _dirty = true);
      });
    }
  }

  Future<void> _load() async {
    final author = widget.id == null
        ? null
        : await context.read<AuthorListNotifier>().findById(widget.id!);
    if (!mounted) return;
    if (author != null) {
      _lastName.text = author.lastName;
      _firstName.text = author.firstName;
      _country.text = author.country;
      _birthYear.text = '${author.birthYear}';
    }
    setState(() {
      _loading = false;
      _dirty = false;
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    await context.read<AuthorListNotifier>().save(
          Author(
            id: widget.id ?? 0,
            lastName: _lastName.text.trim(),
            firstName: _firstName.text.trim(),
            country: _country.text.trim(),
            birthYear: int.parse(_birthYear.text),
          ),
          editing: widget.editing,
        );
    if (!mounted) return;
    setState(() => _dirty = false);
    context.go('/authors');
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return EntityFormScaffold(
      title: widget.editing ? 'Редактирование автора' : 'Новый автор',
      formKey: _formKey,
      dirty: _dirty,
      saving: _saving,
      onCancel: () => context.go('/authors'),
      onSave: _save,
      children: [
        TextFormField(
          controller: _lastName,
          decoration: const InputDecoration(labelText: 'Фамилия'),
          validator: (v) => Validators.requiredText(v, label: 'Фамилия', max: 80),
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _firstName,
          decoration: const InputDecoration(labelText: 'Имя'),
          validator: (v) => Validators.requiredText(v, label: 'Имя', max: 80),
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _country,
          decoration: const InputDecoration(labelText: 'Страна'),
          validator: (v) => Validators.requiredText(v, label: 'Страна', max: 80),
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _birthYear,
          decoration: const InputDecoration(labelText: 'Год рождения'),
          validator: (v) => Validators.year(v, min: 1400, max: DateTime.now().year),
        ),
      ],
    );
  }
}
