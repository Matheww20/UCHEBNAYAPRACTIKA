class Publisher {
  final int id;
  final String name;

  const Publisher(this.id, this.name);
}
