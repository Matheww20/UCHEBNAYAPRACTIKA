import 'package:go_router/go_router.dart';

import 'core/services.dart';
import 'models/models.dart';
import 'screens/books_screen.dart';
import 'screens/home_screen.dart';
import 'screens/loans_screen.dart';
import 'screens/not_found_screen.dart';
import 'screens/simple_editors.dart';
import 'screens/simple_resource_screen.dart';

GoRouter buildRouter(AppServices services) {
  return GoRouter(
    initialLocation: '/',
    routes: [
      GoRoute(
        path: '/',
        builder: (context, state) => HomeScreen(services: services),
      ),
      GoRoute(
        path: '/books',
        builder: (context, state) => BooksScreen(
          services: services,
          initialDelay: int.tryParse(state.uri.queryParameters['__delay'] ?? ''),
          initialFail: int.tryParse(state.uri.queryParameters['__fail'] ?? ''),
        ),
      ),
      GoRoute(
        path: '/authors',
        builder: (context, state) => SimpleResourceScreen<Author>(
          services: services,
          title: 'Авторы',
          repository: services.authors,
          itemTitle: (item) => item.fullName,
          itemSubtitle: (item) => '${item.country} · ${item.birthYear ?? '—'}',
          itemId: (item) => item.id,
          isDeleted: (item) => item.isDeleted,
          sortOptions: const {
            'fullName,asc': 'ФИО ↑',
            'fullName,desc': 'ФИО ↓',
            'birthYear,asc': 'Год рождения ↑',
            'birthYear,desc': 'Год рождения ↓',
          },
          editEntity: (context, item) => editAuthor(context, services, item),
        ),
      ),
      GoRoute(
        path: '/genres',
        builder: (context, state) => SimpleResourceScreen<Genre>(
          services: services,
          title: 'Жанры',
          repository: services.genres,
          itemTitle: (item) => item.name,
          itemSubtitle: (item) => item.description,
          itemId: (item) => item.id,
          isDeleted: (item) => item.isDeleted,
          sortOptions: const {
            'name,asc': 'Название ↑',
            'name,desc': 'Название ↓',
            'id,asc': 'ID ↑',
          },
          editEntity: (context, item) => editGenre(context, services, item),
        ),
      ),
      GoRoute(
        path: '/publishers',
        builder: (context, state) => SimpleResourceScreen<Publisher>(
          services: services,
          title: 'Издательства',
          repository: services.publishers,
          itemTitle: (item) => item.name,
          itemSubtitle: (item) => '${item.city} · основано ${item.foundedYear ?? '—'}',
          itemId: (item) => item.id,
          isDeleted: (item) => item.isDeleted,
          sortOptions: const {
            'name,asc': 'Название ↑',
            'name,desc': 'Название ↓',
            'foundedYear,asc': 'Год основания ↑',
            'foundedYear,desc': 'Год основания ↓',
          },
          editEntity: (context, item) => editPublisher(context, services, item),
        ),
      ),
      GoRoute(
        path: '/readers',
        builder: (context, state) => SimpleResourceScreen<Reader>(
          services: services,
          title: 'Читатели',
          repository: services.readers,
          itemTitle: (item) => item.fullName,
          itemSubtitle: (item) => '${item.email} · ${item.phone} · ${item.card?.number ?? 'без билета'}',
          itemId: (item) => item.id,
          isDeleted: (item) => item.isDeleted,
          sortOptions: const {
            'fullName,asc': 'ФИО ↑',
            'fullName,desc': 'ФИО ↓',
            'email,asc': 'E-mail ↑',
          },
          editEntity: (context, item) => editReader(context, services, item),
        ),
      ),
      GoRoute(
        path: '/loans',
        builder: (context, state) => LoansScreen(services: services),
      ),
    ],
    errorBuilder: (context, state) => NotFoundScreen(location: state.uri.toString()),
  );
}
