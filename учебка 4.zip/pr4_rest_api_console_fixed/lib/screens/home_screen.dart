import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../core/config.dart';
import '../core/services.dart';
import '../widgets/app_top_bar.dart';
import '../widgets/common.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.services});
  final AppServices services;

  @override
  Widget build(BuildContext context) {
    final items = <(String, IconData, String)>[
      ('Книги', Icons.menu_book, '/books'),
      ('Авторы', Icons.people_alt_outlined, '/authors'),
      ('Жанры', Icons.category_outlined, '/genres'),
      ('Издательства', Icons.business_outlined, '/publishers'),
      ('Читатели', Icons.badge_outlined, '/readers'),
      ('Выдачи', Icons.swap_horiz, '/loans'),
    ];

    return Scaffold(
      appBar: AppTopBar(
        services: services,
        title: 'Практическая работа №4',
        showHome: false,
      ),
      body: PageFrame(
        maxWidth: 900,
        child: ListView(
          children: [
            const SizedBox(height: 20),
            Icon(
              Icons.cloud_sync_outlined,
              size: 76,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 14),
            Text(
              'Библиотека — REST API',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineLarge,
            ),
            const SizedBox(height: 8),
            Text(
              'Данные загружаются с $apiBaseUrl через Dio.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            const Text(
              'Для создания, изменения и удаления войдите как admin/admin123.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 28),
            for (final item in items)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: FilledButton.icon(
                  onPressed: () => context.go(item.$3),
                  icon: Icon(item.$2),
                  label: Text(item.$1),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
