import 'package:flutter/material.dart';

class PaginationBar extends StatelessWidget {
  const PaginationBar({
    super.key,
    required this.page,
    required this.totalPages,
    required this.total,
    required this.size,
    required this.onPageChanged,
    required this.onSizeChanged,
  });

  final int page;
  final int totalPages;
  final int total;
  final int size;
  final ValueChanged<int> onPageChanged;
  final ValueChanged<int> onSizeChanged;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 8,
      runSpacing: 8,
      children: [
        IconButton(
          tooltip: 'Первая страница',
          onPressed: page > 1 ? () => onPageChanged(1) : null,
          icon: const Icon(Icons.first_page),
        ),
        IconButton(
          tooltip: 'Предыдущая страница',
          onPressed: page > 1 ? () => onPageChanged(page - 1) : null,
          icon: const Icon(Icons.chevron_left),
        ),
        Text('Страница $page из $totalPages · всего $total'),
        IconButton(
          tooltip: 'Следующая страница',
          onPressed: page < totalPages
              ? () => onPageChanged(page + 1)
              : null,
          icon: const Icon(Icons.chevron_right),
        ),
        IconButton(
          tooltip: 'Последняя страница',
          onPressed: page < totalPages
              ? () => onPageChanged(totalPages)
              : null,
          icon: const Icon(Icons.last_page),
        ),
        const SizedBox(width: 12),
        const Text('На странице:'),
        DropdownButton<int>(
          value: size,
          items: const [
            DropdownMenuItem<int>(value: 10, child: Text('10')),
            DropdownMenuItem<int>(value: 25, child: Text('25')),
            DropdownMenuItem<int>(value: 50, child: Text('50')),
          ],
          onChanged: (value) {
            if (value != null) onSizeChanged(value);
          },
        ),
      ],
    );
  }
}
