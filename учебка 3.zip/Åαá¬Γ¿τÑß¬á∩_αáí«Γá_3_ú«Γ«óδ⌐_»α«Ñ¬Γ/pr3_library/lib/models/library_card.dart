class LibraryCard {
  final String number;
  final DateTime issuedAt;
  final DateTime expiresAt;

  const LibraryCard({required this.number, required this.issuedAt, required this.expiresAt});

  Map<String, dynamic> toJson() => {
    'number': number,
    'issuedAt': issuedAt.toIso8601String(),
    'expiresAt': expiresAt.toIso8601String(),
  };

  factory LibraryCard.fromJson(Map<String, dynamic>? json) {
    final now = DateTime.now();
    if (json == null) {
      return LibraryCard(number: '', issuedAt: now, expiresAt: DateTime(now.year + 1, now.month, now.day));
    }
    return LibraryCard(
      number: json['number'] as String? ?? '',
      issuedAt: DateTime.tryParse('${json['issuedAt']}') ?? now,
      expiresAt: DateTime.tryParse('${json['expiresAt']}') ?? DateTime(now.year + 1, now.month, now.day),
    );
  }
}
