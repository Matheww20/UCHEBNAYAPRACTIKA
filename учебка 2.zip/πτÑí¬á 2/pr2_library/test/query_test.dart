import 'package:flutter_test/flutter_test.dart';
import 'package:pr2_library/models/book_query.dart';

void main() {
  test('BookQuery восстанавливается из URL', () {
    final uri = Uri.parse(
      '/books?search=война&genreId=2&publisherId=1&'
      'yearFrom=1900&yearTo=2025&sort=year,desc&page=2&size=25',
    );

    final query = BookQuery.fromUri(uri);

    expect(query.search, 'война');
    expect(query.genreId, 2);
    expect(query.publisherId, 1);
    expect(query.yearFrom, 1900);
    expect(query.yearTo, 2025);
    expect(query.sortField, 'year');
    expect(query.sortAscending, isFalse);
    expect(query.page, 2);
    expect(query.size, 25);
  });
}
