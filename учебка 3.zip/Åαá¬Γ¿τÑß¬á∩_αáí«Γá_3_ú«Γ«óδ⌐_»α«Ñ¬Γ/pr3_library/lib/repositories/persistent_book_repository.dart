import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../data/seed_data.dart';
import '../models/book.dart';
import '../models/book_query.dart';
import '../models/page_result.dart';
import 'book_repository.dart';

class PersistentBookRepository implements BookRepository {
  static const _key = 'pr3_books_v2';
  final SharedPreferences prefs;
  late List<Book> _items;
  PersistentBookRepository(this.prefs) { _restore(); }

  void _restore() {
    final raw = prefs.getString(_key);
    if (raw == null) { _items = [...seedBooks]; _persist(); return; }
    try {
      final list = jsonDecode(raw) as List;
      _items = list.map((e) => Book.fromJson(Map<String,dynamic>.from(e as Map))).where((b) => b.id > 0).toList();
      if (_items.isEmpty) throw const FormatException('empty');
    } catch (_) { _items = [...seedBooks]; _persist(); prefs.setString('pr3_storage_notice', 'Старые или повреждённые данные книг были сброшены. Используется формат v2.'); }
  }
  Future<void> _persist() async { await prefs.setString(_key, jsonEncode(_items.map((e)=>e.toJson()).toList())); }
  int get _nextId => _items.isEmpty ? 1 : _items.map((e)=>e.id).reduce((a,b)=>a>b?a:b)+1;

  @override Future<PageResult<Book>> find(BookQuery q) async {
    await Future.delayed(const Duration(milliseconds: 180));
    if (q.fail) throw StateError('учебная ошибка загрузки');
    var rows = _items.where((b)=>q.includeDeleted || !b.isDeleted).toList();
    if (q.search.trim().isNotEmpty) { final n=q.search.trim().toLowerCase(); rows=rows.where((b)=>b.title.toLowerCase().contains(n)||b.isbn.toLowerCase().contains(n)).toList(); }
    if (q.genreId!=null) rows=rows.where((b)=>b.genreIds.contains(q.genreId)).toList();
    if (q.publisherId!=null) rows=rows.where((b)=>b.publisherId==q.publisherId).toList();
    if (q.yearFrom!=null) rows=rows.where((b)=>b.year>=q.yearFrom!).toList();
    if (q.yearTo!=null) rows=rows.where((b)=>b.year<=q.yearTo!).toList();
    rows.sort((a,b){ final r=switch(q.sortField){'year'=>a.year.compareTo(b.year),'pages'=>a.pages.compareTo(b.pages),_=>a.title.toLowerCase().compareTo(b.title.toLowerCase())}; return q.sortAscending?r:-r; });
    final total=rows.length, from=(q.page-1)*q.size, to=(from+q.size)>total?total:(from+q.size);
    return PageResult(items: from>=total?<Book>[]:rows.sublist(from,to), page:q.page,size:q.size,total:total);
  }
  @override Future<Book?> findById(int id) async { for(final x in _items) if(x.id==id) return x; return null; }
  @override Future<List<Book>> all() async => List.unmodifiable(_items);
  @override Future<Book> create(Book b) async { final x=Book(id:_nextId,title:b.title,isbn:b.isbn,year:b.year,pages:b.pages,publisherId:b.publisherId,authorIds:b.authorIds,genreIds:b.genreIds,copiesTotal:b.copiesTotal,copiesAvailable:b.copiesAvailable); _items.add(x); await _persist(); return x; }
  @override Future<Book> update(Book b) async { final i=_items.indexWhere((x)=>x.id==b.id); if(i<0) throw StateError('Книга не найдена'); _items[i]=b; await _persist(); return b; }
  @override Future<void> softDelete(int id) async { final i=_items.indexWhere((x)=>x.id==id); if(i<0) return; _items[i]=_items[i].copyWith(deletedAt:DateTime.now()); await _persist(); }
  @override Future<void> hardDelete(int id) async { _items.removeWhere((x)=>x.id==id); await _persist(); }
  @override Future<void> restore(int id) async { final i=_items.indexWhere((x)=>x.id==id); if(i<0) return; _items[i]=_items[i].copyWith(clearDeletedAt:true); await _persist(); }
  @override Future<int> deleteMany(List<int> ids) async { var c=0; for(final id in ids){ final i=_items.indexWhere((b)=>b.id==id && !b.isDeleted); if(i>=0){_items[i]=_items[i].copyWith(deletedAt:DateTime.now()); c++;}} await _persist(); return c; }
  @override Future<bool> isbnExists(String isbn,{int? exceptId}) async => _items.any((b)=>b.id!=exceptId && b.isbn.trim().toLowerCase()==isbn.trim().toLowerCase());
  @override Future<int> countByPublisher(int publisherId) async => _items.where((b)=>!b.isDeleted && b.publisherId==publisherId).length;
  @override Future<Set<int>> authorIdsForPublisher(int publisherId) async => _items.where((b)=>!b.isDeleted && b.publisherId==publisherId).expand((b)=>b.authorIds).toSet();
}
