import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../data/seed_data.dart';
import '../models/author.dart';
import '../state/author_list_notifier.dart';
import '../widgets/app_top_bar.dart';
import '../widgets/page_frame.dart';

class AuthorDetailScreen extends StatefulWidget {
  const AuthorDetailScreen({
    super.key,
    required this.id,
  });

  final int? id;

  @override
  State<AuthorDetailScreen> createState() => _AuthorDetailScreenState();
}

class _AuthorDetailScreenState extends State<AuthorDetailScreen> {
  Future<Author?>? _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    _future ??= widget.id == null
        ? Future<Author?>.value(null)
        : context.read<AuthorListNotifier>().findById(widget.id!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(
        title: 'Карточка автора',
      ),
      body: PageFrame(
        maxWidth: 800,
        child: FutureBuilder<Author?>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }

            final author = snapshot.data;

            if (author == null) {
              return const Center(
                child: Text(
                  'Автор не найден или указан некорректный идентификатор.',
                ),
              );
            }

            final books = seedBooks
                .where(
                  (book) => book.authorIds.contains(author.id),
                )
                .toList();

            return SingleChildScrollView(
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        author.fullName,
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const SizedBox(height: 20),
                      _row('Фамилия', author.lastName),
                      _row('Имя', author.firstName),
                      _row('Страна', author.country),
                      _row(
                        'Год рождения',
                        '${author.birthYear}',
                      ),
                      _row(
                        'Статус',
                        author.isDeleted
                            ? 'Логически удалён'
                            : 'Активен',
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'Книги автора',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 8),
                      if (books.isEmpty)
                        const Text('Книг нет')
                      else
                        for (final book in books)
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: Text(book.title),
                            subtitle: Text('${book.year}'),
                            onTap: () => context.go(
                              '/books/${book.id}',
                            ),
                          ),
                      const SizedBox(height: 16),
                      OutlinedButton.icon(
                        onPressed: () => context.go('/authors'),
                        icon: const Icon(Icons.arrow_back),
                        label: const Text('К списку авторов'),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _row(
    String label,
    String value,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          SizedBox(
            width: 150,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }
}
