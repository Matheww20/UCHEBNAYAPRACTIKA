import 'package:flutter_test/flutter_test.dart';
import 'package:pr2_library/models/book_query.dart';
import 'package:pr2_library/repositories/in_memory_book_repository.dart';

void main() {
  test('по умолчанию возвращаются первые 10 книг', () async {
    final repo = InMemoryBookRepository();
    final result = await repo.find(const BookQuery());

    expect(result.items.length, 10);
    expect(result.total, 24);
  });

  test('поиск работает по названию', () async {
    final repo = InMemoryBookRepository();
    final result = await repo.find(
      const BookQuery(search: 'война'),
    );

    expect(
      result.items.any((book) => book.title == 'Война и мир'),
      isTrue,
    );
  });

  test('фильтры жанр, издательство и годы работают вместе', () async {
    final repo = InMemoryBookRepository();
    final result = await repo.find(
      const BookQuery(
        genreId: 4,
        publisherId: 4,
        yearFrom: 2018,
        yearTo: 2024,
      ),
    );

    expect(
      result.items.every(
        (book) =>
            book.genreIds.contains(4) &&
            book.publisherId == 4 &&
            book.year >= 2018 &&
            book.year <= 2024,
      ),
      isTrue,
    );
  });

  test('пагинация возвращает вторую страницу', () async {
    final repo = InMemoryBookRepository();
    final result = await repo.find(
      const BookQuery(
        page: 2,
        size: 10,
      ),
    );

    expect(result.page, 2);
    expect(result.items.length, 10);
  });

  test('множественное логическое удаление работает', () async {
    final repo = InMemoryBookRepository();

    final deleted = await repo.deleteMany([1, 2]);
    expect(deleted, 2);

    final normal = await repo.find(
      const BookQuery(size: 50),
    );

    expect(
      normal.items.any(
        (book) => book.id == 1 || book.id == 2,
      ),
      isFalse,
    );

    final withDeleted = await repo.find(
      const BookQuery(
        size: 50,
        includeDeleted: true,
      ),
    );

    expect(
      withDeleted.items
          .where(
            (book) => book.id == 1 || book.id == 2,
          )
          .every(
            (book) => book.isDeleted,
          ),
      isTrue,
    );
  });
}
