import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/genre.dart';
import '../state/genre_notifier.dart';
import '../widgets/app_top_bar.dart';
import '../widgets/page_frame.dart';

class GenreDetailScreen extends StatelessWidget {
  const GenreDetailScreen({super.key, required this.id});
  final int? id;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(title: 'Карточка жанра'),
      body: PageFrame(
        maxWidth: 700,
        child: FutureBuilder<Genre?>(
          future: id == null ? Future<Genre?>.value(null) : context.read<GenreNotifier>().findById(id!),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            final item = snapshot.data;
            if (item == null) return const Center(child: Text('Жанр не найден'));
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.name, style: Theme.of(context).textTheme.headlineSmall),
                    const SizedBox(height: 16),
                    Text('Статус: ${item.isDeleted ? 'Удалён' : 'Активен'}'),
                    const SizedBox(height: 20),
                    OutlinedButton(
                      onPressed: () => context.go('/genres'),
                      child: const Text('К списку'),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
