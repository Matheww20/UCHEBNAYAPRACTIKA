import 'package:flutter_test/flutter_test.dart';
import 'package:pr2_library/models/author_query.dart';
import 'package:pr2_library/repositories/in_memory_author_repository.dart';

void main() {
  test('в начальном наборе не менее 8 авторов', () async {
    final repo = InMemoryAuthorRepository();
    final result = await repo.find(
      const AuthorQuery(size: 50),
    );

    expect(
      result.total,
      greaterThanOrEqualTo(8),
    );
  });

  test('поиск автора работает по фамилии', () async {
    final repo = InMemoryAuthorRepository();
    final result = await repo.find(
      const AuthorQuery(search: 'толстой'),
    );

    expect(result.items.single.lastName, 'Толстой');
  });

  test('фильтр по стране работает', () async {
    final repo = InMemoryAuthorRepository();
    final result = await repo.find(
      const AuthorQuery(
        country: 'США',
        size: 50,
      ),
    );

    expect(
      result.items.every(
        (author) => author.country == 'США',
      ),
      isTrue,
    );
  });
}
