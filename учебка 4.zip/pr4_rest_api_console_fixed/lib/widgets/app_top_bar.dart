import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../core/api_exceptions.dart';
import '../core/services.dart';

class AppTopBar extends StatelessWidget implements PreferredSizeWidget {
  const AppTopBar({
    super.key,
    required this.services,
    required this.title,
    this.showHome = true,
  });

  final AppServices services;
  final String title;
  final bool showHome;

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: services.session,
      builder: (context, _) {
        return AppBar(
          title: Text(title),
          leading: showHome
              ? IconButton(
                  tooltip: 'На главную',
                  onPressed: () => context.go('/'),
                  icon: const Icon(Icons.home_outlined),
                )
              : null,
          actions: [
            if (services.session.isLoggedIn)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Center(
                  child: Text(
                    '${services.session.username} (${services.session.role})',
                  ),
                ),
              ),
            if (!services.session.isLoggedIn)
              TextButton.icon(
                onPressed: () => showLoginDialog(context, services),
                icon: const Icon(Icons.login),
                label: const Text('Войти'),
              ),
            if (services.session.isLoggedIn)
              IconButton(
                tooltip: 'Выйти',
                onPressed: () async {
                  await services.auth.logout();
                },
                icon: const Icon(Icons.logout),
              ),
            const SizedBox(width: 8),
          ],
        );
      },
    );
  }
}

Future<void> showLoginDialog(
  BuildContext context,
  AppServices services,
) async {
  await showDialog<void>(
    context: context,
    builder: (dialogContext) {
      return _LoginDialog(services: services);
    },
  );
}

class _LoginDialog extends StatefulWidget {
  const _LoginDialog({
    required this.services,
  });

  final AppServices services;

  @override
  State<_LoginDialog> createState() => _LoginDialogState();
}

class _LoginDialogState extends State<_LoginDialog> {
  late final TextEditingController _login;
  late final TextEditingController _password;

  bool _loading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _login = TextEditingController(text: 'admin');
    _password = TextEditingController(text: 'admin123');
  }

  @override
  void dispose() {
    _login.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_loading) return;

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      await widget.services.auth.login(
        _login.text.trim(),
        _password.text,
      );

      if (!mounted) return;

      // Важно: после успешного входа больше не вызываем setState
      // у закрывающегося диалога.
      Navigator.of(context).pop();
      return;
    } on ApiException catch (e) {
      if (!mounted) return;

      setState(() {
        _error = e.message;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _error = 'Не удалось выполнить вход: $e';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_loading,
      child: AlertDialog(
        title: const Text('Вход в API'),
        content: SizedBox(
          width: 420,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _login,
                enabled: !_loading,
                decoration: const InputDecoration(
                  labelText: 'Логин',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _password,
                enabled: !_loading,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Пароль',
                  border: OutlineInputBorder(),
                ),
                onSubmitted: (_) => _submit(),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(
                  _error!,
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.error,
                  ),
                ),
              ],
              const SizedBox(height: 12),
              const Text(
                'Для полной проверки используйте admin / admin123.',
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: _loading
                ? null
                : () => Navigator.of(context).pop(),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: _loading ? null : _submit,
            child: _loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                    ),
                  )
                : const Text('Войти'),
          ),
        ],
      ),
    );
  }
}
