import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../data/seed_data.dart';
import '../models/book.dart';
import '../state/book_list_notifier.dart';
import '../widgets/app_top_bar.dart';
import '../widgets/page_frame.dart';

class BookDetailScreen extends StatefulWidget {
  const BookDetailScreen({
    super.key,
    required this.id,
  });

  final int? id;

  @override
  State<BookDetailScreen> createState() => _BookDetailScreenState();
}

class _BookDetailScreenState extends State<BookDetailScreen> {
  Future<Book?>? _future;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    _future ??= widget.id == null
        ? Future<Book?>.value(null)
        : context.read<BookListNotifier>().findById(widget.id!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(
        title: 'Карточка книги',
      ),
      body: PageFrame(
        maxWidth: 800,
        child: FutureBuilder<Book?>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }

            final book = snapshot.data;

            if (book == null) {
              return const Center(
                child: Text(
                  'Книга не найдена или указан некорректный идентификатор.',
                ),
              );
            }

            return SingleChildScrollView(
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        book.title,
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const SizedBox(height: 20),
                      _row('ISBN', book.isbn),
                      _row('Год', '${book.year}'),
                      _row('Страниц', '${book.pages}'),
                      _row(
                        'Издательство',
                        publisherName(book.publisherId),
                      ),
                      _row(
                        'Авторы',
                        book.authorIds.map(authorName).join(', '),
                      ),
                      _row(
                        'Жанры',
                        book.genreIds.map(genreName).join(', '),
                      ),
                      _row(
                        'Экземпляров',
                        '${book.copiesAvailable} из ${book.copiesTotal}',
                      ),
                      _row(
                        'Статус',
                        book.isDeleted
                            ? 'Логически удалена'
                            : 'Активна',
                      ),
                      const SizedBox(height: 20),
                      OutlinedButton.icon(
                        onPressed: () => context.go('/books'),
                        icon: const Icon(Icons.arrow_back),
                        label: const Text('К каталогу'),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _row(
    String label,
    String value,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 150,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }
}
