import 'package:flutter/material.dart';
import 'package:flutter_web_plugins/url_strategy.dart';

import 'core/services.dart';
import 'router.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  usePathUrlStrategy();

  final services = AppServices.create();
  runApp(LibraryApiApp(services: services));
}

class LibraryApiApp extends StatefulWidget {
  const LibraryApiApp({super.key, required this.services});
  final AppServices services;

  @override
  State<LibraryApiApp> createState() => _LibraryApiAppState();
}

class _LibraryApiAppState extends State<LibraryApiApp> {
  late final router = buildRouter(widget.services);

  @override
  void dispose() {
    router.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Библиотека — REST API',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
        ),
      ),
      routerConfig: router,
    );
  }
}
