class SimpleQuery {
  final String search;
  final String sortField;
  final bool sortAscending;
  final int page;
  final int size;
  final bool includeDeleted;

  const SimpleQuery({
    this.search = '',
    this.sortField = 'name',
    this.sortAscending = true,
    this.page = 1,
    this.size = 10,
    this.includeDeleted = false,
  });

  SimpleQuery copyWith({
    String? search,
    String? sortField,
    bool? sortAscending,
    int? page,
    int? size,
    bool? includeDeleted,
  }) => SimpleQuery(
    search: search ?? this.search,
    sortField: sortField ?? this.sortField,
    sortAscending: sortAscending ?? this.sortAscending,
    page: page ?? 1,
    size: size ?? this.size,
    includeDeleted: includeDeleted ?? this.includeDeleted,
  );

  factory SimpleQuery.fromUri(Uri uri, {String defaultSort = 'name'}) {
    final p = uri.queryParameters;
    final sort = (p['sort'] ?? '$defaultSort,asc').split(',');
    final rawPage = int.tryParse(p['page'] ?? '') ?? 1;
    final rawSize = int.tryParse(p['size'] ?? '') ?? 10;
    return SimpleQuery(
      search: p['search'] ?? '',
      sortField: sort.first,
      sortAscending: sort.length < 2 || sort[1] != 'desc',
      page: rawPage < 1 ? 1 : rawPage,
      size: const [10, 25, 50].contains(rawSize) ? rawSize : 10,
      includeDeleted: p['deleted'] == '1',
    );
  }

  Map<String, String> toParams({String defaultSort = 'name'}) {
    final p = <String, String>{};
    if (search.trim().isNotEmpty) p['search'] = search.trim();
    if (sortField != defaultSort || !sortAscending) p['sort'] = '$sortField,${sortAscending ? 'asc' : 'desc'}';
    if (page != 1) p['page'] = '$page';
    if (size != 10) p['size'] = '$size';
    if (includeDeleted) p['deleted'] = '1';
    return p;
  }

  @override
  bool operator ==(Object other) => other is SimpleQuery && search == other.search && sortField == other.sortField && sortAscending == other.sortAscending && page == other.page && size == other.size && includeDeleted == other.includeDeleted;
  @override
  int get hashCode => Object.hash(search, sortField, sortAscending, page, size, includeDeleted);
}
