# Практическая работа №2 — списки, поиск, фильтрация и пагинация

Это отдельный Flutter Web-проект для ПР2.

Реализовано:

- `Book` и `Author`;
- 24 книги и 10 авторов;
- слои `models`, `repositories`, `state`, `screens`, `widgets`;
- управление состоянием через `provider`;
- `go_router`;
- список и карточка для книг и авторов;
- загрузка, успех, пустой результат и ошибка;
- поиск книг по названию/ISBN;
- поиск авторов по фамилии/стране;
- фильтры книг: жанр, издательство, диапазон лет;
- множественное логическое удаление;
- логическое и физическое удаление;
- показ удалённых и восстановление;
- при ширине меньше 600 px — карточки, иначе таблица;
- пагинация 10/25/50;
- сортировка минимум по трём полям;
- общая таблица `EntityTable<T>`;
- параметры поиска/фильтров/сортировки/страницы в URL;
- debounce поиска 350 мс;
- исправленная ошибка `deleteMany` из методички.

## Запуск

Открой терминал в папке проекта:

```bat
flutter pub get
flutter run -d chrome --web-port=5556
```

## Проверка

```bat
flutter analyze
flutter test
```

## Адреса для проверки и скриншотов

Главная:

```text
http://localhost:5556/
```

Каталог книг:

```text
http://localhost:5556/books
```

Пример одновременно применённых фильтров:

```text
http://localhost:5556/books?search=деньги&genreId=4&publisherId=4&yearFrom=2018&yearTo=2024&sort=year,desc
```

Пустой результат:

```text
http://localhost:5556/books?search=qwertyxyz
```

Состояние ошибки:

```text
http://localhost:5556/books?fail=1
```

Авторы:

```text
http://localhost:5556/authors
```

Карточка автора:

```text
http://localhost:5556/authors/1
```

Карточка книги:

```text
http://localhost:5556/books/1
```

## Ошибка deleteMany из методички

В методичке намеренно оставлено:

```dart
final i = _books.indexWhere((b) => b.id == id && !b[i].isDeleted);
```

Это неверно: `b` уже является одной книгой, а `i` ещё только вычисляется.

В проекте исправлено на:

```dart
final i = _books.indexWhere((b) => b.id == id && !b.isDeleted);
```

## Схема слоёв

```text
screens/widgets
      ↓
state (provider)
      ↓
repositories
      ↓
models/data
```

`EntityTable<T>` используется и для книг, и для авторов, поэтому таблица,
выделение строк и сортировка не дублируются.
