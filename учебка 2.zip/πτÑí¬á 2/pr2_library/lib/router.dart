import 'package:go_router/go_router.dart';

import 'models/author_query.dart';
import 'models/book_query.dart';
import 'screens/author_detail_screen.dart';
import 'screens/authors_screen.dart';
import 'screens/book_detail_screen.dart';
import 'screens/books_screen.dart';
import 'screens/home_screen.dart';
import 'screens/not_found_screen.dart';

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/books',
      builder: (context, state) {
        return BooksScreen(
          query: BookQuery.fromUri(state.uri),
        );
      },
      routes: [
        GoRoute(
          path: ':id',
          builder: (context, state) {
            return BookDetailScreen(
              id: int.tryParse(
                state.pathParameters['id'] ?? '',
              ),
            );
          },
        ),
      ],
    ),
    GoRoute(
      path: '/authors',
      builder: (context, state) {
        return AuthorsScreen(
          query: AuthorQuery.fromUri(state.uri),
        );
      },
      routes: [
        GoRoute(
          path: ':id',
          builder: (context, state) {
            return AuthorDetailScreen(
              id: int.tryParse(
                state.pathParameters['id'] ?? '',
              ),
            );
          },
        ),
      ],
    ),
  ],
  errorBuilder: (context, state) {
    return NotFoundScreen(
      location: state.uri.toString(),
    );
  },
);
