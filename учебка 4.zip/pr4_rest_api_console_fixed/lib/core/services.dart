import 'package:dio/dio.dart';

import '../models/models.dart';
import '../repositories/repositories.dart';
import 'api_client.dart';
import 'session.dart';

class AppServices {
  final Session session;
  final Dio dio;
  late final AuthRepository auth;
  late final BookRepository books;
  late final ApiCrudRepository<Author> authors;
  late final ApiCrudRepository<Genre> genres;
  late final ApiCrudRepository<Publisher> publishers;
  late final ApiCrudRepository<Reader> readers;
  late final LoanRepository loans;
  late final ReferenceCache references;

  AppServices._(this.session, this.dio) {
    auth = AuthRepository(dio, session);
    books = BookRepository(dio);
    authors = ApiCrudRepository<Author>(
      dio: dio,
      endpoint: '/authors',
      parser: Author.fromJson,
      serializer: (item) => item.toInputJson(),
    );
    genres = ApiCrudRepository<Genre>(
      dio: dio,
      endpoint: '/genres',
      parser: Genre.fromJson,
      serializer: (item) => item.toInputJson(),
    );
    publishers = ApiCrudRepository<Publisher>(
      dio: dio,
      endpoint: '/publishers',
      parser: Publisher.fromJson,
      serializer: (item) => item.toInputJson(),
    );
    readers = ApiCrudRepository<Reader>(
      dio: dio,
      endpoint: '/readers',
      parser: Reader.fromJson,
      serializer: (item) => item.toInputJson(),
    );
    loans = LoanRepository(dio);
    references = ReferenceCache(
      authorsRepo: authors,
      genresRepo: genres,
      publishersRepo: publishers,
    );
  }

  factory AppServices.create() {
    final session = Session();
    final dio = buildDio(tokenProvider: () => session.accessToken);
    return AppServices._(session, dio);
  }
}
