class Genre {
  final int id;
  final String name;
  final DateTime? deletedAt;

  const Genre(this.id, this.name, {this.deletedAt});
  bool get isDeleted => deletedAt != null;

  Genre copyWith({String? name, DateTime? deletedAt, bool clearDeletedAt = false}) =>
      Genre(id, name ?? this.name, deletedAt: clearDeletedAt ? null : (deletedAt ?? this.deletedAt));

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'deletedAt': deletedAt?.toIso8601String()};

  factory Genre.fromJson(Map<String, dynamic> json) => Genre(
    json['id'] is int ? json['id'] as int : int.tryParse('${json['id']}') ?? 0,
    json['name'] as String? ?? '',
    deletedAt: json['deletedAt'] == null ? null : DateTime.tryParse('${json['deletedAt']}'),
  );
}
