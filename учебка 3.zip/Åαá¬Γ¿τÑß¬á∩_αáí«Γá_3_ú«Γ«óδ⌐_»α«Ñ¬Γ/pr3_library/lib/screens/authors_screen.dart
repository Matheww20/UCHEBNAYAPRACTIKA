import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../data/seed_data.dart';
import '../models/author.dart';
import '../models/author_query.dart';
import '../state/author_list_notifier.dart';
import '../state/load_status.dart';
import '../widgets/app_top_bar.dart';
import '../widgets/entity_table.dart';
import '../widgets/page_frame.dart';
import '../widgets/pagination_bar.dart';
import '../widgets/state_views.dart';

class AuthorsScreen extends StatefulWidget {
  const AuthorsScreen({
    super.key,
    required this.query,
  });

  final AuthorQuery query;

  @override
  State<AuthorsScreen> createState() => _AuthorsScreenState();
}

class _AuthorsScreenState extends State<AuthorsScreen> {
  late final TextEditingController _searchController;
  Timer? _debounce;

  static const countries = [
    'Россия',
    'США',
    'Великобритания',
  ];

  @override
  void initState() {
    super.initState();

    _searchController = TextEditingController(
      text: widget.query.search,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AuthorListNotifier>().applyQuery(widget.query);
    });
  }

  @override
  void didUpdateWidget(covariant AuthorsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.query != widget.query) {
      if (_searchController.text != widget.query.search) {
        _searchController.text = widget.query.search;
      }

      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.read<AuthorListNotifier>().applyQuery(widget.query);
      });
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  void _go(AuthorQuery query) {
    final parameters = query.toQueryParameters();

    final uri = Uri(
      path: '/authors',
      queryParameters: parameters.isEmpty ? null : parameters,
    );

    context.go(uri.toString());
  }

  void _onSearchChanged(String value) {
    _debounce?.cancel();

    _debounce = Timer(
      const Duration(milliseconds: 350),
      () {
        if (!mounted) return;

        _go(
          widget.query.copyWith(
            search: value,
          ),
        );
      },
    );
  }

  Future<void> _confirmDeleteSelected(
    AuthorListNotifier notifier,
  ) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Удалить выбранных?'),
          content: Text(
            'Выбрано авторов: ${notifier.selected.length}. '
            'Будет выполнено логическое удаление.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Отмена'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Удалить'),
            ),
          ],
        );
      },
    );

    if (ok == true) {
      await notifier.deleteSelected();
    }
  }

  Future<void> _confirmHardDelete(
    AuthorListNotifier notifier,
    Author author,
  ) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Физическое удаление'),
          content: Text(
            'Удалить ${author.fullName} без возможности восстановления?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Отмена'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Удалить навсегда'),
            ),
          ],
        );
      },
    );

    if (ok == true) {
      await notifier.hardDelete(author.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final notifier = context.watch<AuthorListNotifier>();

    return Scaffold(
      appBar: const AppTopBar(title: 'Авторы'),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => context.go('/authors/new'), icon: const Icon(Icons.add), label: const Text('Добавить автора')),
      body: PageFrame(
        child: Column(
          children: [
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                SizedBox(
                  width: 320,
                  child: TextField(
                    controller: _searchController,
                    decoration: const InputDecoration(
                      labelText: 'Поиск по фамилии или стране',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(),
                    ),
                    onChanged: _onSearchChanged,
                  ),
                ),
                SizedBox(
                  width: 220,
                  child: DropdownButtonFormField<String>(
                    value: widget.query.country ?? '__all__',
                    decoration: const InputDecoration(
                      labelText: 'Страна',
                      border: OutlineInputBorder(),
                    ),
                    items: [
                      const DropdownMenuItem<String>(
                        value: '__all__',
                        child: Text('Все страны'),
                      ),
                      ...countries.map(
                        (country) => DropdownMenuItem<String>(
                          value: country,
                          child: Text(country),
                        ),
                      ),
                    ],
                    onChanged: (value) {
                      _go(
                        widget.query.copyWith(
                          country: value == '__all__'
                              ? null
                              : value,
                        ),
                      );
                    },
                  ),
                ),
                FilterChip(
                  selected: widget.query.includeDeleted,
                  label: const Text('Показывать удалённых'),
                  onSelected: (value) {
                    _go(
                      widget.query.copyWith(
                        includeDeleted: value,
                      ),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (notifier.hasSelection)
              Align(
                alignment: Alignment.centerLeft,
                child: FilledButton.icon(
                  onPressed: () => _confirmDeleteSelected(notifier),
                  icon: const Icon(Icons.delete_sweep),
                  label: Text(
                    'Удалить выбранных (${notifier.selected.length})',
                  ),
                ),
              ),
            if (notifier.hasSelection)
              const SizedBox(height: 12),
            Expanded(
              child: _body(notifier),
            ),
          ],
        ),
      ),
    );
  }

  Widget _body(AuthorListNotifier notifier) {
    if (notifier.status == LoadStatus.loading ||
        notifier.status == LoadStatus.idle) {
      return const LoadingView();
    }

    if (notifier.status == LoadStatus.error) {
      return ErrorView(
        message: notifier.error ?? 'Ошибка',
        onRetry: notifier.load,
      );
    }

    if (notifier.result.items.isEmpty) {
      return const EmptyView();
    }

    return Column(
      children: [
        Expanded(
          child: LayoutBuilder(
            builder: (context, constraints) {
              if (constraints.maxWidth < 600) {
                return _cards(notifier);
              }

              return SingleChildScrollView(
                child: EntityTable<Author>(
                  items: notifier.result.items,
                  idOf: (author) => author.id,
                  selected: notifier.selected,
                  onToggleSelect: notifier.toggleSelection,
                  sortField: notifier.query.sortField,
                  sortAscending: notifier.query.sortAscending,
                  onSort: (field) {
                    final same = field == widget.query.sortField;

                    _go(
                      widget.query.copyWith(
                        sortField: field,
                        sortAscending: same
                            ? !widget.query.sortAscending
                            : true,
                      ),
                    );
                  },
                  columns: [
                    TableColumnSpec<Author>(
                      label: 'Фамилия',
                      sortField: 'lastName',
                      build: (author) => Text(
                        author.lastName,
                        style: author.isDeleted
                            ? const TextStyle(
                                decoration: TextDecoration.lineThrough,
                              )
                            : null,
                      ),
                    ),
                    TableColumnSpec<Author>(
                      label: 'Имя',
                      build: (author) => Text(author.firstName),
                    ),
                    TableColumnSpec<Author>(
                      label: 'Страна',
                      sortField: 'country',
                      build: (author) => Text(author.country),
                    ),
                    TableColumnSpec<Author>(
                      label: 'Год рождения',
                      sortField: 'birthYear',
                      numeric: true,
                      build: (author) => Text('${author.birthYear}'),
                    ),
                    TableColumnSpec<Author>(
                      label: 'Книг',
                      numeric: true,
                      build: (author) => Text(
                        '${booksCountForAuthor(author.id)}',
                      ),
                    ),
                  ],
                  actions: (author) => _authorActions(
                    notifier,
                    author,
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        PaginationBar(
          page: notifier.result.page,
          totalPages: notifier.result.totalPages,
          total: notifier.result.total,
          size: notifier.result.size,
          onPageChanged: (page) {
            _go(
              widget.query.copyWith(page: page),
            );
          },
          onSizeChanged: (size) {
            _go(
              widget.query.copyWith(size: size),
            );
          },
        ),
      ],
    );
  }

  Widget _cards(AuthorListNotifier notifier) {
    return ListView.separated(
      itemCount: notifier.result.items.length,
      separatorBuilder: (_, __) {
        return const SizedBox(height: 8);
      },
      itemBuilder: (context, index) {
        final author = notifier.result.items[index];

        return Card(
          child: ListTile(
            leading: Checkbox(
              value: notifier.selected.contains(author.id),
              onChanged: (_) {
                notifier.toggleSelection(author.id);
              },
            ),
            title: Text(
              author.fullName,
              style: author.isDeleted
                  ? const TextStyle(
                      decoration: TextDecoration.lineThrough,
                    )
                  : null,
            ),
            subtitle: Text(
              '${author.country} · ${author.birthYear} · '
              'книг: ${booksCountForAuthor(author.id)}',
            ),
            trailing: Wrap(
              spacing: 2,
              children: _authorActions(
                notifier,
                author,
              ),
            ),
          ),
        );
      },
    );
  }

  List<Widget> _authorActions(
    AuthorListNotifier notifier,
    Author author,
  ) {
    return [
      IconButton(
        tooltip: 'Просмотр',
        onPressed: () => context.go(
          '/authors/${author.id}',
        ),
        icon: const Icon(Icons.visibility_outlined),
      ),
      IconButton(tooltip: 'Редактировать', onPressed: () => context.go('/authors/${author.id}/edit'), icon: const Icon(Icons.edit_outlined)),
      if (!author.isDeleted)
        IconButton(
          tooltip: 'Логически удалить',
          onPressed: () => notifier.softDelete(author.id),
          icon: const Icon(Icons.delete_outline),
        ),
      if (author.isDeleted)
        IconButton(
          tooltip: 'Восстановить',
          onPressed: () => notifier.restore(author.id),
          icon: const Icon(Icons.restore),
        ),
      if (author.isDeleted)
        IconButton(
          tooltip: 'Удалить навсегда',
          onPressed: () => _confirmHardDelete(
            notifier,
            author,
          ),
          icon: const Icon(Icons.delete_forever),
        ),
    ];
  }
}
