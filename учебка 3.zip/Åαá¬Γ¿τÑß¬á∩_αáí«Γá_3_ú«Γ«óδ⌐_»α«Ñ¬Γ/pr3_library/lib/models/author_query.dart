class AuthorQuery {
  final String search;
  final String? country;
  final String sortField;
  final bool sortAscending;
  final int page;
  final int size;
  final bool includeDeleted;
  final bool fail;

  const AuthorQuery({
    this.search = '',
    this.country,
    this.sortField = 'lastName',
    this.sortAscending = true,
    this.page = 1,
    this.size = 10,
    this.includeDeleted = false,
    this.fail = false,
  });

  static const _unset = Object();

  AuthorQuery copyWith({
    String? search,
    Object? country = _unset,
    String? sortField,
    bool? sortAscending,
    int? page,
    int? size,
    bool? includeDeleted,
    bool? fail,
  }) {
    return AuthorQuery(
      search: search ?? this.search,
      country: country == _unset ? this.country : country as String?,
      sortField: sortField ?? this.sortField,
      sortAscending: sortAscending ?? this.sortAscending,
      page: page ?? 1,
      size: size ?? this.size,
      includeDeleted: includeDeleted ?? this.includeDeleted,
      fail: fail ?? this.fail,
    );
  }

  factory AuthorQuery.fromUri(Uri uri) {
    final p = uri.queryParameters;
    final sort = (p['sort'] ?? 'lastName,asc').split(',');
    final rawPage = int.tryParse(p['page'] ?? '') ?? 1;
    final rawSize = int.tryParse(p['size'] ?? '') ?? 10;

    return AuthorQuery(
      search: p['search'] ?? '',
      country: (p['country'] ?? '').isEmpty ? null : p['country'],
      sortField: sort.isNotEmpty ? sort.first : 'lastName',
      sortAscending: sort.length < 2 || sort[1] != 'desc',
      page: rawPage < 1 ? 1 : rawPage,
      size: const [10, 25, 50].contains(rawSize) ? rawSize : 10,
      includeDeleted: p['deleted'] == '1',
      fail: p['fail'] == '1',
    );
  }

  Map<String, String> toQueryParameters() {
    final p = <String, String>{};
    if (search.trim().isNotEmpty) p['search'] = search.trim();
    if (country != null && country!.isNotEmpty) p['country'] = country!;
    if (sortField != 'lastName' || !sortAscending) {
      p['sort'] = '$sortField,${sortAscending ? 'asc' : 'desc'}';
    }
    if (page != 1) p['page'] = '$page';
    if (size != 10) p['size'] = '$size';
    if (includeDeleted) p['deleted'] = '1';
    if (fail) p['fail'] = '1';
    return p;
  }

  @override
  bool operator ==(Object other) {
    return other is AuthorQuery &&
        search == other.search &&
        country == other.country &&
        sortField == other.sortField &&
        sortAscending == other.sortAscending &&
        page == other.page &&
        size == other.size &&
        includeDeleted == other.includeDeleted &&
        fail == other.fail;
  }

  @override
  int get hashCode => Object.hash(
        search,
        country,
        sortField,
        sortAscending,
        page,
        size,
        includeDeleted,
        fail,
      );
}
