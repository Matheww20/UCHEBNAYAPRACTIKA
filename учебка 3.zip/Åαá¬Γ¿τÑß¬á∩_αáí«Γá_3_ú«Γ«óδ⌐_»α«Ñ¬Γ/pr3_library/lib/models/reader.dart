import 'library_card.dart';

class Reader {
  final int id;
  final String lastName;
  final String firstName;
  final String email;
  final LibraryCard card;
  final DateTime? deletedAt;

  const Reader({
    required this.id,
    required this.lastName,
    required this.firstName,
    required this.email,
    required this.card,
    this.deletedAt,
  });

  bool get isDeleted => deletedAt != null;
  String get fullName => '$lastName $firstName';

  Reader copyWith({
    String? lastName,
    String? firstName,
    String? email,
    LibraryCard? card,
    DateTime? deletedAt,
    bool clearDeletedAt = false,
  }) => Reader(
    id: id,
    lastName: lastName ?? this.lastName,
    firstName: firstName ?? this.firstName,
    email: email ?? this.email,
    card: card ?? this.card,
    deletedAt: clearDeletedAt ? null : (deletedAt ?? this.deletedAt),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'lastName': lastName,
    'firstName': firstName,
    'email': email,
    'card': card.toJson(),
    'deletedAt': deletedAt?.toIso8601String(),
  };

  factory Reader.fromJson(Map<String, dynamic> json) => Reader(
    id: json['id'] is int ? json['id'] as int : int.tryParse('${json['id']}') ?? 0,
    lastName: json['lastName'] as String? ?? '',
    firstName: json['firstName'] as String? ?? '',
    email: json['email'] as String? ?? '',
    card: LibraryCard.fromJson(json['card'] is Map ? Map<String, dynamic>.from(json['card'] as Map) : null),
    deletedAt: json['deletedAt'] == null ? null : DateTime.tryParse('${json['deletedAt']}'),
  );
}
