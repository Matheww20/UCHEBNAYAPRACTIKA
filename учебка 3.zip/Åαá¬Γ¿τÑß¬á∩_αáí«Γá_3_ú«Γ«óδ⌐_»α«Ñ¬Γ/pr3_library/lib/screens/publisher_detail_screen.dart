import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/publisher.dart';
import '../state/book_list_notifier.dart';
import '../state/publisher_notifier.dart';
import '../widgets/app_top_bar.dart';
import '../widgets/page_frame.dart';

class PublisherDetailScreen extends StatelessWidget {
  const PublisherDetailScreen({super.key, required this.id});
  final int? id;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(title: 'Карточка издательства'),
      body: PageFrame(
        maxWidth: 700,
        child: FutureBuilder<Publisher?>(
          future: id == null ? Future<Publisher?>.value(null) : context.read<PublisherNotifier>().findById(id!),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            final item = snapshot.data;
            if (item == null) return const Center(child: Text('Издательство не найдено'));
            return FutureBuilder<int>(
              future: context.read<BookListNotifier>().repository.countByPublisher(item.id),
              builder: (context, countSnapshot) {
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.name, style: Theme.of(context).textTheme.headlineSmall),
                        const SizedBox(height: 16),
                        Text('Связанных книг: ${countSnapshot.data ?? 0}'),
                        Text('Статус: ${item.isDeleted ? 'Удалено' : 'Активно'}'),
                        const SizedBox(height: 20),
                        OutlinedButton(
                          onPressed: () => context.go('/publishers'),
                          child: const Text('К списку'),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
