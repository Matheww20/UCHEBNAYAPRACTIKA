import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AppTopBar extends StatelessWidget implements PreferredSizeWidget {
  const AppTopBar({
    super.key,
    required this.title,
    this.showHome = true,
  });

  final String title;
  final bool showHome;

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Text(title),
      leading: showHome
          ? IconButton(
              tooltip: 'На главную',
              onPressed: () => context.go('/'),
              icon: const Icon(Icons.home_outlined),
            )
          : null,
    );
  }
}
