import 'package:flutter/foundation.dart';
import '../models/book.dart'; import '../models/book_query.dart'; import '../models/page_result.dart'; import '../repositories/book_repository.dart'; import 'load_status.dart';
class BookListNotifier extends ChangeNotifier{
 final BookRepository repository; BookListNotifier(this.repository); BookQuery _query=const BookQuery(); PageResult<Book> _result=PageResult<Book>.empty(); LoadStatus _status=LoadStatus.idle; String? _error; final Set<int> _selected={};
 BookQuery get query=>_query; PageResult<Book> get result=>_result; LoadStatus get status=>_status; String? get error=>_error; Set<int> get selected=>Set.unmodifiable(_selected); bool get hasSelection=>_selected.isNotEmpty;
 Future<void> applyQuery(BookQuery q) async{_query=q;_selected.clear();await load();} Future<void> load() async{_status=LoadStatus.loading;_error=null;notifyListeners();try{_result=await repository.find(_query);_status=LoadStatus.success;}catch(e){_error='Не удалось загрузить список: $e';_status=LoadStatus.error;}notifyListeners();}
 void toggleSelection(int id){_selected.contains(id)?_selected.remove(id):_selected.add(id);notifyListeners();} Future<void> deleteSelected() async{await repository.deleteMany(_selected.toList());_selected.clear();await load();}
 Future<void> softDelete(int id) async{await repository.softDelete(id);await load();} Future<void> hardDelete(int id) async{await repository.hardDelete(id);await load();} Future<void> restore(int id) async{await repository.restore(id);await load();}
 Future<Book?> findById(int id)=>repository.findById(id); Future<List<Book>> all()=>repository.all(); Future<Book> save(Book b,{required bool editing}) async{final x=editing?await repository.update(b):await repository.create(b);await load();return x;} Future<bool> isbnExists(String isbn,{int? exceptId})=>repository.isbnExists(isbn,exceptId:exceptId); Future<Set<int>> authorIdsForPublisher(int id)=>repository.authorIdsForPublisher(id);
}
