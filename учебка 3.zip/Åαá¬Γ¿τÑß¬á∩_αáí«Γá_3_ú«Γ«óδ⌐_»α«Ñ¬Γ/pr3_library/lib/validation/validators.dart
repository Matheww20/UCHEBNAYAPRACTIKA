class Validators {
  static String? requiredText(String? value, {String label = 'Поле', int max = 120}) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) return '$label обязательно для заполнения';
    if (v.length > max) return 'Не более $max символов';
    return null;
  }

  static String? year(String? value, {int min = 1000, int? max}) {
    if ((value ?? '').trim().isEmpty) return 'Введите год';
    final n = int.tryParse(value!.trim());
    final upper = max ?? DateTime.now().year + 1;
    if (n == null) return 'Год должен быть числом';
    if (n < min || n > upper) return 'Допустимый диапазон: $min–$upper';
    return null;
  }

  static String? positiveInt(String? value, {String label = 'Значение', int max = 100000}) {
    if ((value ?? '').trim().isEmpty) return 'Введите $label';
    final n = int.tryParse(value!.trim());
    if (n == null) return '$label должно быть целым числом';
    if (n < 0) return '$label не может быть отрицательным';
    if (n > max) return '$label слишком большое';
    return null;
  }

  static String? email(String? value) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) return 'Введите адрес почты';
    if (v.length > 160) return 'Не более 160 символов';
    final ok = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v);
    return ok ? null : 'Некорректный формат почты';
  }

  static String? isbn(String? value) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) return 'Введите ISBN';
    if (v.length < 10 || v.length > 20) return 'ISBN должен содержать 10–20 символов';
    if (!RegExp(r'^[0-9Xx\-]+$').hasMatch(v)) return 'Допустимы цифры, X и дефисы';
    return null;
  }

  static String? cardNumber(String? value) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) return 'Введите номер билета';
    if (v.length < 4 || v.length > 30) return 'От 4 до 30 символов';
    return null;
  }
}
