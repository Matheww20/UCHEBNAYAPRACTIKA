import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../widgets/app_top_bar.dart';
import '../widgets/page_frame.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(
        title: 'Главная',
        showHome: false,
      ),
      body: PageFrame(
        maxWidth: 900,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.local_library_outlined,
                size: 76,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: 20),
              Text(
                'Учебная библиотека',
                style: Theme.of(context).textTheme.headlineLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              const Text(
                'Списки, поиск, фильтрация, сортировка, пагинация и адресная строка',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: 420,
                child: FilledButton.icon(
                  onPressed: () => context.go('/books'),
                  icon: const Icon(Icons.menu_book),
                  label: const Text('Каталог книг'),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: 420,
                child: FilledButton.icon(
                  onPressed: () => context.go('/authors'),
                  icon: const Icon(Icons.people_alt_outlined),
                  label: const Text('Авторы'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
