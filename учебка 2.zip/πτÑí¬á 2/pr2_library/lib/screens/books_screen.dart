import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../data/seed_data.dart';
import '../models/book.dart';
import '../models/book_query.dart';
import '../state/book_list_notifier.dart';
import '../state/load_status.dart';
import '../widgets/app_top_bar.dart';
import '../widgets/entity_table.dart';
import '../widgets/page_frame.dart';
import '../widgets/pagination_bar.dart';
import '../widgets/state_views.dart';

class BooksScreen extends StatefulWidget {
  const BooksScreen({
    super.key,
    required this.query,
  });

  final BookQuery query;

  @override
  State<BooksScreen> createState() => _BooksScreenState();
}

class _BooksScreenState extends State<BooksScreen> {
  late final TextEditingController _searchController;
  late final TextEditingController _yearFromController;
  late final TextEditingController _yearToController;

  Timer? _debounce;

  @override
  void initState() {
    super.initState();

    _searchController = TextEditingController(
      text: widget.query.search,
    );
    _yearFromController = TextEditingController(
      text: widget.query.yearFrom?.toString() ?? '',
    );
    _yearToController = TextEditingController(
      text: widget.query.yearTo?.toString() ?? '',
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<BookListNotifier>().applyQuery(widget.query);
    });
  }

  @override
  void didUpdateWidget(covariant BooksScreen oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.query != widget.query) {
      if (_searchController.text != widget.query.search) {
        _searchController.text = widget.query.search;
      }

      final yearFrom = widget.query.yearFrom?.toString() ?? '';
      final yearTo = widget.query.yearTo?.toString() ?? '';

      if (_yearFromController.text != yearFrom) {
        _yearFromController.text = yearFrom;
      }

      if (_yearToController.text != yearTo) {
        _yearToController.text = yearTo;
      }

      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.read<BookListNotifier>().applyQuery(widget.query);
      });
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController.dispose();
    _yearFromController.dispose();
    _yearToController.dispose();
    super.dispose();
  }

  void _go(BookQuery query) {
    final parameters = query.toQueryParameters();

    final uri = Uri(
      path: '/books',
      queryParameters: parameters.isEmpty ? null : parameters,
    );

    context.go(uri.toString());
  }

  void _onSearchChanged(String value) {
    _debounce?.cancel();

    _debounce = Timer(
      const Duration(milliseconds: 350),
      () {
        if (!mounted) return;
        _go(widget.query.copyWith(search: value));
      },
    );
  }

  void _applyYears() {
    final from = int.tryParse(
      _yearFromController.text.trim(),
    );
    final to = int.tryParse(
      _yearToController.text.trim(),
    );

    _go(
      widget.query.copyWith(
        yearFrom: from,
        yearTo: to,
      ),
    );
  }

  Future<void> _confirmDeleteSelected(
    BookListNotifier notifier,
  ) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Удалить выбранные?'),
          content: Text(
            'Выбрано записей: ${notifier.selected.length}. '
            'Будет выполнено логическое удаление.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Отмена'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Удалить'),
            ),
          ],
        );
      },
    );

    if (ok == true) {
      await notifier.deleteSelected();
    }
  }

  Future<void> _confirmHardDelete(
    BookListNotifier notifier,
    Book book,
  ) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Физическое удаление'),
          content: Text(
            'Удалить «${book.title}» без возможности восстановления?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Отмена'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Удалить навсегда'),
            ),
          ],
        );
      },
    );

    if (ok == true) {
      await notifier.hardDelete(book.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final notifier = context.watch<BookListNotifier>();

    return Scaffold(
      appBar: const AppTopBar(
        title: 'Каталог книг',
      ),
      body: PageFrame(
        child: Column(
          children: [
            _filters(),
            const SizedBox(height: 12),
            if (notifier.hasSelection)
              Align(
                alignment: Alignment.centerLeft,
                child: FilledButton.icon(
                  onPressed: () => _confirmDeleteSelected(notifier),
                  icon: const Icon(Icons.delete_sweep),
                  label: Text(
                    'Удалить выбранные (${notifier.selected.length})',
                  ),
                ),
              ),
            if (notifier.hasSelection)
              const SizedBox(height: 12),
            Expanded(
              child: _body(notifier),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filters() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth >= 1000;

        return Wrap(
          spacing: 10,
          runSpacing: 10,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            SizedBox(
              width: wide ? 260 : constraints.maxWidth,
              child: TextField(
                controller: _searchController,
                decoration: const InputDecoration(
                  labelText: 'Поиск по названию или ISBN',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onChanged: _onSearchChanged,
              ),
            ),
            SizedBox(
              width: wide ? 190 : 260,
              child: DropdownButtonFormField<int>(
                value: widget.query.genreId ?? 0,
                decoration: const InputDecoration(
                  labelText: 'Жанр',
                  border: OutlineInputBorder(),
                ),
                items: [
                  const DropdownMenuItem<int>(
                    value: 0,
                    child: Text('Все жанры'),
                  ),
                  ...genres.map(
                    (genre) => DropdownMenuItem<int>(
                      value: genre.id,
                      child: Text(genre.name),
                    ),
                  ),
                ],
                onChanged: (value) {
                  _go(
                    widget.query.copyWith(
                      genreId: value == 0 ? null : value,
                    ),
                  );
                },
              ),
            ),
            SizedBox(
              width: wide ? 210 : 260,
              child: DropdownButtonFormField<int>(
                value: widget.query.publisherId ?? 0,
                decoration: const InputDecoration(
                  labelText: 'Издательство',
                  border: OutlineInputBorder(),
                ),
                items: [
                  const DropdownMenuItem<int>(
                    value: 0,
                    child: Text('Все издательства'),
                  ),
                  ...publishers.map(
                    (publisher) => DropdownMenuItem<int>(
                      value: publisher.id,
                      child: Text(publisher.name),
                    ),
                  ),
                ],
                onChanged: (value) {
                  _go(
                    widget.query.copyWith(
                      publisherId: value == 0 ? null : value,
                    ),
                  );
                },
              ),
            ),
            SizedBox(
              width: 120,
              child: TextField(
                controller: _yearFromController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Год от',
                  border: OutlineInputBorder(),
                ),
                onSubmitted: (_) => _applyYears(),
              ),
            ),
            SizedBox(
              width: 120,
              child: TextField(
                controller: _yearToController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Год до',
                  border: OutlineInputBorder(),
                ),
                onSubmitted: (_) => _applyYears(),
              ),
            ),
            OutlinedButton.icon(
              onPressed: _applyYears,
              icon: const Icon(Icons.filter_alt_outlined),
              label: const Text('Применить годы'),
            ),
            FilterChip(
              selected: widget.query.includeDeleted,
              label: const Text('Показывать удалённые'),
              onSelected: (value) {
                _go(
                  widget.query.copyWith(
                    includeDeleted: value,
                  ),
                );
              },
            ),
          ],
        );
      },
    );
  }

  Widget _body(BookListNotifier notifier) {
    if (notifier.status == LoadStatus.loading ||
        notifier.status == LoadStatus.idle) {
      return const LoadingView();
    }

    if (notifier.status == LoadStatus.error) {
      return ErrorView(
        message: notifier.error ?? 'Ошибка',
        onRetry: notifier.load,
      );
    }

    if (notifier.result.items.isEmpty) {
      return const EmptyView();
    }

    return Column(
      children: [
        Expanded(
          child: LayoutBuilder(
            builder: (context, constraints) {
              if (constraints.maxWidth < 600) {
                return _cards(notifier);
              }

              return SingleChildScrollView(
                child: EntityTable<Book>(
                  items: notifier.result.items,
                  idOf: (book) => book.id,
                  selected: notifier.selected,
                  onToggleSelect: notifier.toggleSelection,
                  sortField: notifier.query.sortField,
                  sortAscending: notifier.query.sortAscending,
                  onSort: (field) {
                    final same = field == widget.query.sortField;

                    _go(
                      widget.query.copyWith(
                        sortField: field,
                        sortAscending: same
                            ? !widget.query.sortAscending
                            : true,
                      ),
                    );
                  },
                  columns: [
                    TableColumnSpec<Book>(
                      label: 'Название',
                      sortField: 'title',
                      build: (book) => Text(
                        book.title,
                        style: book.isDeleted
                            ? const TextStyle(
                                decoration: TextDecoration.lineThrough,
                              )
                            : null,
                      ),
                    ),
                    TableColumnSpec<Book>(
                      label: 'ISBN',
                      build: (book) => Text(book.isbn),
                    ),
                    TableColumnSpec<Book>(
                      label: 'Год',
                      sortField: 'year',
                      numeric: true,
                      build: (book) => Text('${book.year}'),
                    ),
                    TableColumnSpec<Book>(
                      label: 'Страниц',
                      sortField: 'pages',
                      numeric: true,
                      build: (book) => Text('${book.pages}'),
                    ),
                    TableColumnSpec<Book>(
                      label: 'Издательство',
                      build: (book) => Text(
                        publisherName(book.publisherId),
                      ),
                    ),
                    TableColumnSpec<Book>(
                      label: 'Жанры',
                      build: (book) => Text(
                        book.genreIds.map(genreName).join(', '),
                      ),
                    ),
                  ],
                  actions: (book) => _bookActions(
                    notifier,
                    book,
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        PaginationBar(
          page: notifier.result.page,
          totalPages: notifier.result.totalPages,
          total: notifier.result.total,
          size: notifier.result.size,
          onPageChanged: (page) {
            _go(
              widget.query.copyWith(page: page),
            );
          },
          onSizeChanged: (size) {
            _go(
              widget.query.copyWith(size: size),
            );
          },
        ),
      ],
    );
  }

  Widget _cards(BookListNotifier notifier) {
    return ListView.separated(
      itemCount: notifier.result.items.length,
      separatorBuilder: (_, __) {
        return const SizedBox(height: 8);
      },
      itemBuilder: (context, index) {
        final book = notifier.result.items[index];

        return Card(
          child: ListTile(
            leading: Checkbox(
              value: notifier.selected.contains(book.id),
              onChanged: (_) {
                notifier.toggleSelection(book.id);
              },
            ),
            title: Text(
              book.title,
              style: book.isDeleted
                  ? const TextStyle(
                      decoration: TextDecoration.lineThrough,
                    )
                  : null,
            ),
            subtitle: Text(
              '${book.year} · '
              '${publisherName(book.publisherId)} · '
              '${book.genreIds.map(genreName).join(', ')}',
            ),
            trailing: Wrap(
              spacing: 2,
              children: _bookActions(
                notifier,
                book,
              ),
            ),
          ),
        );
      },
    );
  }

  List<Widget> _bookActions(
    BookListNotifier notifier,
    Book book,
  ) {
    return [
      IconButton(
        tooltip: 'Просмотр',
        onPressed: () => context.go(
          '/books/${book.id}',
        ),
        icon: const Icon(Icons.visibility_outlined),
      ),
      if (!book.isDeleted)
        IconButton(
          tooltip: 'Логически удалить',
          onPressed: () => notifier.softDelete(book.id),
          icon: const Icon(Icons.delete_outline),
        ),
      if (book.isDeleted)
        IconButton(
          tooltip: 'Восстановить',
          onPressed: () => notifier.restore(book.id),
          icon: const Icon(Icons.restore),
        ),
      if (book.isDeleted)
        IconButton(
          tooltip: 'Удалить навсегда',
          onPressed: () => _confirmHardDelete(
            notifier,
            book,
          ),
          icon: const Icon(Icons.delete_forever),
        ),
    ];
  }
}
