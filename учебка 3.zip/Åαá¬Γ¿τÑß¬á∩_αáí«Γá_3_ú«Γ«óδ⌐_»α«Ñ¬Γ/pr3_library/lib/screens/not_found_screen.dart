import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../widgets/app_top_bar.dart';

class NotFoundScreen extends StatelessWidget {
  const NotFoundScreen({
    super.key,
    required this.location,
  });

  final String location;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(
        title: 'Ошибка 404',
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.search_off,
              size: 72,
            ),
            const SizedBox(height: 16),
            const Text('Страница не найдена'),
            const SizedBox(height: 8),
            SelectableText(location),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: () => context.go('/'),
              child: const Text('На главную'),
            ),
          ],
        ),
      ),
    );
  }
}
