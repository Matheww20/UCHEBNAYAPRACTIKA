import 'package:flutter/foundation.dart';
import '../models/genre.dart'; import '../models/page_result.dart'; import '../models/simple_query.dart'; import '../repositories/genre_repository.dart'; import 'load_status.dart';
class GenreNotifier extends ChangeNotifier{final GenreRepository repository;GenreNotifier(this.repository);SimpleQuery _query=const SimpleQuery();PageResult<Genre> _result=PageResult<Genre>.empty();LoadStatus _status=LoadStatus.idle;String? _error;
 SimpleQuery get query=>_query;PageResult<Genre> get result=>_result;LoadStatus get status=>_status;String? get error=>_error;
 Future<void> applyQuery(SimpleQuery q)async{_query=q;await load();}Future<void> load()async{_status=LoadStatus.loading;notifyListeners();try{_result=await repository.find(_query);_status=LoadStatus.success;_error=null;}catch(e){_error='$e';_status=LoadStatus.error;}notifyListeners();}
 Future<Genre?> findById(int id)=>repository.findById(id);Future<Genre> save(Genre x,{required bool editing})async{final r=editing?await repository.update(x):await repository.create(x);await load();return r;}Future<void> softDelete(int id)async{await repository.softDelete(id);await load();}Future<void> hardDelete(int id)async{await repository.hardDelete(id);await load();}Future<void> restore(int id)async{await repository.restore(id);await load();}Future<List<Genre>> allActive()=>repository.allActive();
}
