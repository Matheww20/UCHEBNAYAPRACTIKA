class Publisher {
  final int id;
  final String name;
  final DateTime? deletedAt;

  const Publisher(this.id, this.name, {this.deletedAt});
  bool get isDeleted => deletedAt != null;

  Publisher copyWith({String? name, DateTime? deletedAt, bool clearDeletedAt = false}) =>
      Publisher(id, name ?? this.name, deletedAt: clearDeletedAt ? null : (deletedAt ?? this.deletedAt));

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'deletedAt': deletedAt?.toIso8601String()};

  factory Publisher.fromJson(Map<String, dynamic> json) => Publisher(
    json['id'] is int ? json['id'] as int : int.tryParse('${json['id']}') ?? 0,
    json['name'] as String? ?? '',
    deletedAt: json['deletedAt'] == null ? null : DateTime.tryParse('${json['deletedAt']}'),
  );
}
