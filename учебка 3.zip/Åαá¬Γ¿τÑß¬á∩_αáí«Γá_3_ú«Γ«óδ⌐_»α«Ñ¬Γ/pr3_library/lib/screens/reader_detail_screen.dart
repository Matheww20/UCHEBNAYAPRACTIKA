import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/reader.dart';
import '../state/reader_notifier.dart';
import '../widgets/app_top_bar.dart';
import '../widgets/page_frame.dart';

class ReaderDetailScreen extends StatelessWidget {
  const ReaderDetailScreen({super.key, required this.id});
  final int? id;

  String _format(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}.${d.year}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const AppTopBar(title: 'Карточка читателя'),
      body: PageFrame(
        maxWidth: 760,
        child: FutureBuilder<Reader?>(
          future: id == null ? Future<Reader?>.value(null) : context.read<ReaderNotifier>().findById(id!),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            final reader = snapshot.data;
            if (reader == null) return const Center(child: Text('Читатель не найден'));
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(reader.fullName, style: Theme.of(context).textTheme.headlineSmall),
                    const SizedBox(height: 16),
                    Text('E-mail: ${reader.email}'),
                    const SizedBox(height: 18),
                    Text('Читательский билет', style: Theme.of(context).textTheme.titleMedium),
                    Text('Номер: ${reader.card.number}'),
                    Text('Выдан: ${_format(reader.card.issuedAt)}'),
                    Text('Действует до: ${_format(reader.card.expiresAt)}'),
                    const SizedBox(height: 20),
                    OutlinedButton(
                      onPressed: () => context.go('/readers'),
                      child: const Text('К списку'),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
