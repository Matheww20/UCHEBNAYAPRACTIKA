import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../data/seed_data.dart';
import '../models/author.dart';
import '../models/author_query.dart';
import '../models/page_result.dart';
import 'author_repository.dart';
class PersistentAuthorRepository implements AuthorRepository {
  static const _key='pr3_authors_v2'; final SharedPreferences prefs; late List<Author> _items;
  PersistentAuthorRepository(this.prefs){_restore();}
  void _restore(){final raw=prefs.getString(_key); if(raw==null){_items=[...seedAuthors];_persist();return;} try{final l=jsonDecode(raw) as List;_items=l.map((e)=>Author.fromJson(Map<String,dynamic>.from(e as Map))).where((x)=>x.id>0).toList();if(_items.isEmpty)throw const FormatException();}catch(_){_items=[...seedAuthors];_persist();prefs.setString('pr3_storage_notice','Старые данные авторов были сброшены. Формат v2.');}}
  Future<void> _persist() async { await prefs.setString(_key,jsonEncode(_items.map((e)=>e.toJson()).toList())); } int get _nextId=>_items.isEmpty?1:_items.map((e)=>e.id).reduce((a,b)=>a>b?a:b)+1;
  @override Future<PageResult<Author>> find(AuthorQuery q) async{await Future.delayed(const Duration(milliseconds:180));if(q.fail)throw StateError('учебная ошибка загрузки');var rows=_items.where((a)=>q.includeDeleted||!a.isDeleted).toList();if(q.search.trim().isNotEmpty){final n=q.search.trim().toLowerCase();rows=rows.where((a)=>a.lastName.toLowerCase().contains(n)||a.country.toLowerCase().contains(n)).toList();}if(q.country!=null)rows=rows.where((a)=>a.country==q.country).toList();rows.sort((a,b){final r=switch(q.sortField){'country'=>a.country.compareTo(b.country),'birthYear'=>a.birthYear.compareTo(b.birthYear),_=>a.lastName.toLowerCase().compareTo(b.lastName.toLowerCase())};return q.sortAscending?r:-r;});final total=rows.length,from=(q.page-1)*q.size,to=(from+q.size)>total?total:(from+q.size);return PageResult(items:from>=total?<Author>[]:rows.sublist(from,to),page:q.page,size:q.size,total:total);}
  @override Future<Author?> findById(int id) async{for(final x in _items)if(x.id==id)return x;return null;}
  @override Future<List<Author>> allActive() async=>_items.where((x)=>!x.isDeleted).toList();
  @override Future<Author> create(Author a) async{final x=Author(id:_nextId,lastName:a.lastName,firstName:a.firstName,country:a.country,birthYear:a.birthYear);_items.add(x);await _persist();return x;}
  @override Future<Author> update(Author a) async{final i=_items.indexWhere((x)=>x.id==a.id);if(i<0)throw StateError('Автор не найден');_items[i]=a;await _persist();return a;}
  @override Future<void> softDelete(int id) async{final i=_items.indexWhere((x)=>x.id==id);if(i>=0){_items[i]=_items[i].copyWith(deletedAt:DateTime.now());await _persist();}}
  @override Future<void> hardDelete(int id) async{_items.removeWhere((x)=>x.id==id);await _persist();}
  @override Future<void> restore(int id) async{final i=_items.indexWhere((x)=>x.id==id);if(i>=0){_items[i]=_items[i].copyWith(clearDeletedAt:true);await _persist();}}
  @override Future<int> deleteMany(List<int> ids) async{var c=0;for(final id in ids){final i=_items.indexWhere((x)=>x.id==id&&!x.isDeleted);if(i>=0){_items[i]=_items[i].copyWith(deletedAt:DateTime.now());c++;}}await _persist();return c;}
}
