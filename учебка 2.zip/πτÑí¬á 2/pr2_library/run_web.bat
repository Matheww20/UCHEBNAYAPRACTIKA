@echo off
flutter pub get
flutter run -d chrome --web-port=5556
pause
