@echo off
flutter analyze
flutter test
pause
