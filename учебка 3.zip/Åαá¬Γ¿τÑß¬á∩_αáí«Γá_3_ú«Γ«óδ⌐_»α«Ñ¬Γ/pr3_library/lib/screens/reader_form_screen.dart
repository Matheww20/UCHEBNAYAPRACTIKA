import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../models/library_card.dart';
import '../models/reader.dart';
import '../state/reader_notifier.dart';
import '../validation/validators.dart';
import '../widgets/entity_form_scaffold.dart';

class ReaderFormScreen extends StatefulWidget {
  const ReaderFormScreen({super.key, this.id});
  final int? id;

  @override
  State<ReaderFormScreen> createState() => _ReaderFormScreenState();
}

class _ReaderFormScreenState extends State<ReaderFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _lastName = TextEditingController();
  final _firstName = TextEditingController();
  final _email = TextEditingController();
  final _card = TextEditingController();
  final _issued = TextEditingController();
  final _expires = TextEditingController();

  bool _loading = true;
  bool _dirty = false;
  bool _saving = false;
  String? _emailError;

  @override
  void initState() {
    super.initState();
    _load();
    for (final c in [_lastName, _firstName, _email, _card, _issued, _expires]) {
      c.addListener(() {
        if (mounted) setState(() => _dirty = true);
      });
    }
  }

  String _formatDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _load() async {
    final reader = widget.id == null
        ? null
        : await context.read<ReaderNotifier>().findById(widget.id!);
    final now = DateTime.now();
    if (!mounted) return;
    if (reader != null) {
      _lastName.text = reader.lastName;
      _firstName.text = reader.firstName;
      _email.text = reader.email;
      _card.text = reader.card.number;
      _issued.text = _formatDate(reader.card.issuedAt);
      _expires.text = _formatDate(reader.card.expiresAt);
    } else {
      _issued.text = _formatDate(now);
      _expires.text = _formatDate(DateTime(now.year + 1, now.month, now.day));
    }
    setState(() {
      _loading = false;
      _dirty = false;
    });
  }

  String? _dateValidator(String? value) {
    if ((value ?? '').isEmpty) return 'Введите дату YYYY-MM-DD';
    return DateTime.tryParse(value!) == null ? 'Формат YYYY-MM-DD' : null;
  }

  Future<void> _save() async {
    setState(() => _emailError = null);
    if (!_formKey.currentState!.validate()) return;

    final notifier = context.read<ReaderNotifier>();
    final duplicate = await notifier.emailExists(_email.text, exceptId: widget.id);
    if (duplicate) {
      setState(() => _emailError = 'Такой адрес почты уже используется');
      _formKey.currentState!.validate();
      return;
    }

    setState(() => _saving = true);
    final reader = Reader(
      id: widget.id ?? 0,
      lastName: _lastName.text.trim(),
      firstName: _firstName.text.trim(),
      email: _email.text.trim(),
      card: LibraryCard(
        number: _card.text.trim(),
        issuedAt: DateTime.parse(_issued.text),
        expiresAt: DateTime.parse(_expires.text),
      ),
    );
    await notifier.save(
          reader,
          editing: widget.id != null,
        );
    if (!mounted) return;
    setState(() => _dirty = false);
    context.go('/readers');
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return EntityFormScaffold(
      title: widget.id == null ? 'Новый читатель' : 'Редактирование читателя',
      formKey: _formKey,
      dirty: _dirty,
      saving: _saving,
      onCancel: () => context.go('/readers'),
      onSave: _save,
      children: [
        TextFormField(
          controller: _lastName,
          decoration: const InputDecoration(labelText: 'Фамилия'),
          validator: (v) => Validators.requiredText(v, label: 'Фамилия', max: 80),
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _firstName,
          decoration: const InputDecoration(labelText: 'Имя'),
          validator: (v) => Validators.requiredText(v, label: 'Имя', max: 80),
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _email,
          decoration: InputDecoration(labelText: 'E-mail', errorText: _emailError),
          validator: (v) => _emailError ?? Validators.email(v),
        ),
        const SizedBox(height: 22),
        Text('Читательский билет', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        TextFormField(
          controller: _card,
          decoration: const InputDecoration(labelText: 'Номер билета'),
          validator: Validators.cardNumber,
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                controller: _issued,
                decoration: const InputDecoration(labelText: 'Выдан (YYYY-MM-DD)'),
                validator: _dateValidator,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: TextFormField(
                controller: _expires,
                decoration: const InputDecoration(labelText: 'Действует до'),
                validator: (v) {
                  final error = _dateValidator(v);
                  if (error != null) return error;
                  final start = DateTime.tryParse(_issued.text);
                  final end = DateTime.tryParse(v!);
                  if (start != null && end != null && !end.isAfter(start)) {
                    return 'Дата должна быть позже выдачи';
                  }
                  return null;
                },
              ),
            ),
          ],
        ),
      ],
    );
  }
}
